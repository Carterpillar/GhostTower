var towerI,towerImg;
var door,doorImg,doorsGp;
var climber,climberImg,climb;
var ghost,ghostImg;
var Invisibleground,ig;
var gamestate = "play"; 
 
function preload(){
towerImg = loadImage("tower.png");  
doorImg = loadImage("door.png"); 
climberImg = loadImage("climber.png"); 
ghostImg = loadImage("ghost-standing.png");

}
function setup(){
createCanvas(windowWidth,windowHeight);   
  
towerI = createSprite(375,300);  
towerI.addImage("tower",towerImg);  
towerI.velocityY = 5; 
towerI.scale = 1.2;

ghost = createSprite(375,500);
ghost.addImage("gt",ghostImg);
ghost.scale = 0.5;
 
  
  
doorsGp = new Group() ;
climb = new Group();
ig = new Group();
}

function draw(){
background("black");
if(gamestate == "play"){
if(towerI.y>400){
towerI.y = 100;

}
if(keyDown("left_Arrow")){
ghost.x = ghost.x-5; 
}
if(keyDown("right_Arrow")){
ghost.x = ghost.x+5; 
}
if(keyDown("space")){
ghost.velocityY = -5;
}
if (climb.isTouching(ghost)){
ghost.velocityY = 0; 
}
if(ig.isTouching(ghost) || ghost.y>600 ){
ghost.destroy();   
}
ghost.velocityY=ghost.velocityY+0.8; 
doors();
drawSprites(); 
}
if (gamestate =="end"){
stroke("red");  
fill("yellow");  
textSize(15);  
text("GameOver",375,300);  
} 
}
function doors(){
if (frameCount%200== 0){
var door= createSprite(300,300);    
door.x = Math.round(random(100,500));
door.addImage("door2",doorImg);  
door.velocityY = 5;
door.scale = 1;
door.lifetime = 300;
doorsGp.add(door);
ghost.depth = door.depth;
ghost.depth = ghost.depth+1;

var climber = createSprite(300,370);
climber.addImage("cr",climberImg);
climber.x = door.x;
climber.velocityY = 5;
climber.lifetime = 300;
climb.add(climber);

var InvisibleGround = createSprite(300,300);
InvisibleGround.width = climber.width;
InvisibleGround.height = 2;
InvisibleGround.x = door.x;
InvisibleGround.velocityY = 5;
InvisibleGround.debug = false;
ig.add(InvisibleGround);
}
}
